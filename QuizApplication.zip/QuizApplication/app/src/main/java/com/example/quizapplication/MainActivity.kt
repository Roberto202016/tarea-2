package com.example.quizapplication

import android.graphics.Color
import android.graphics.Color.BLACK
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.widget.Button
import android.widget.TextView
import android.widget.Toast


class MainActivity : AppCompatActivity() {

    private lateinit var txtQuestion: TextView
    private lateinit var txtResultados: TextView
    private lateinit var btnTrue: Button
    private lateinit var btnFalse: Button
    private lateinit var btnNext: Button
    private lateinit var btnPrev: Button

    private val questions = mutableListOf<Question>()
    private var currentQuestionIndex = 0
    var count_buenas = 0
    private var count = 0

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        Log.d("QUIZAPP_LIFECYCLE", "OnCreate()...")

        setContentView(R.layout.activity_main)

        txtQuestion = findViewById(R.id.question_text)
        txtResultados = findViewById(R.id.resultados)
        btnTrue = findViewById(R.id.true_button)
        btnFalse = findViewById(R.id.false_button)
        btnNext = findViewById(R.id.next_button)
        btnPrev = findViewById(R.id.prev_button)

        questions.add(Question("¿La luna es de queso?", true, false, false))
        questions.add(Question("¿Existe Santa-Claus?", false, false, false))
        questions.add(Question("¿El hombre llegó a la luna?", false, false, false))
        questions.add(Question("¿La tierra es plana?", true, false, false))
        questions.add(Question("¿Es Kotlin mejor que Java?", true, false, false))
        questions.add(Question("¿El cielo realmente es azul?", false, false, false))

        txtQuestion.text = questions[0].text
        count = questions.size

        txtResultados.text = "Te faltan " + count.toString() + " preguntas"

        txtQuestion.text = questions[currentQuestionIndex].text;

        btnTrue.setOnClickListener { v ->
            // Toast.makeText(this, "Correct!", Toast.LENGTH_SHORT).show()
            validar(true)
            respondido()
        }

        btnFalse.setOnClickListener { v ->
            //Toast.makeText(this, "Incorrect!", Toast.LENGTH_SHORT).show()
            validar(false)
            respondido()
        }

        btnNext.setOnClickListener { v ->

            currentQuestionIndex = (currentQuestionIndex + 1) % questions.size
            txtQuestion.text = questions[currentQuestionIndex].text
            txtQuestion.setTextColor(Color.BLACK)
            respondido()
        }

        btnPrev.setOnClickListener { v ->
            currentQuestionIndex = (currentQuestionIndex - 1) % questions.size
            txtQuestion.text = questions[currentQuestionIndex].text
            txtQuestion.setTextColor(Color.BLACK)
            respondido()
        }


        /*
        TAREA #1
        1. Agregar boton PREV (previous) y su funcionalidad
        2. Implementar validación de la respuesta correcta
        3. Indicar de manera visual que una pregunta ya fue respondida (correcta e incorrecta)
        4. No permitir responder una pregunta más de una vez
        5. Indicador de "pregunta actual"/"total de preguntas" en la parte superior de la pantalla
        6. Indicador de "puntuación"
         */
    }

    fun validar(response: Boolean) {
        questions[currentQuestionIndex].check = true
        count -= 1

        if (response == questions[currentQuestionIndex].answer) {
            txtQuestion.setTextColor(Color.GREEN)
            questions[currentQuestionIndex].respondido = true

            count_buenas += 1

        } else {
            txtQuestion.setTextColor(Color.RED)
            questions[currentQuestionIndex].respondido = true

        }
        txtResultados.text = "Preguntas restantes: " + count.toString()

        if (count == 0) {
            Toast.makeText(this, "Respuestas correctas: " + count_buenas, Toast.LENGTH_SHORT).show()
        }


    }

    fun respondido() {
        if (questions[currentQuestionIndex].respondido) {
            btnTrue.isEnabled = false
            btnFalse.isEnabled = false

        } else {
            btnTrue.isEnabled = true
            btnFalse.isEnabled = true
        }
    }

}