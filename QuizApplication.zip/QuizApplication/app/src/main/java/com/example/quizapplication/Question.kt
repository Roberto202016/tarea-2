package com.example.quizapplication

data class Question(val text: String, val answer: Boolean,var check:Boolean,var respondido:Boolean)

